using System.Collections.Generic;
using System.Linq;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using JSE_RevitAddin_MEP_OPENINGS.Services;
using JSE_RevitAddin_MEP_OPENINGS.Services.Helpers;

namespace JSE_RevitAddin_MEP_OPENINGS.Commands
{
    [Transaction(TransactionMode.Manual)]
    public class PipeOpeningsRectCommand : IExternalCommand
    {
        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            UIDocument uiDoc = commandData.Application.ActiveUIDocument;
            Document doc = uiDoc.Document;
            // Create a dedicated log file under the repo Log directory for this command
            string repoRoot = System.IO.Path.GetDirectoryName(doc.PathName) ?? System.Environment.CurrentDirectory;
            string logDir = System.IO.Path.Combine(repoRoot, "Log");
            try { if (!System.IO.Directory.Exists(logDir)) System.IO.Directory.CreateDirectory(logDir); } catch { }
            string timestamp = System.DateTime.Now.ToString("yyyyMMdd_HHmmss");
            string commandLogPath = System.IO.Path.Combine(logDir, $"PipeOpeningsRect_{timestamp}.log");
            void AppendCommandLog(string line)
            {
                try { System.IO.File.AppendAllLines(commandLogPath, new[] { $"[{System.DateTime.Now:yyyy-MM-dd HH:mm:ss}] {line}" }); } catch { }
            }

            int placedCount = 0;
            int deletedCount = 0;

            // Collect all placed pipe sleeves (assuming circular PS# family instances)
            double toleranceDist = UnitUtils.ConvertToInternalUnits(100.0, UnitTypeId.Millimeters);
            double toleranceMm = UnitUtils.ConvertFromInternalUnits(toleranceDist, UnitTypeId.Millimeters);
            double zTolerance = UnitUtils.ConvertToInternalUnits(15.0, UnitTypeId.Millimeters);
            var rawSleeves = new FilteredElementCollector(doc)
                .OfClass(typeof(FamilyInstance))
                .Cast<FamilyInstance>()
                .Where(fi =>
                {
                    var famName = fi.Symbol.Family.Name ?? string.Empty;
                    var symName = fi.Symbol.Name ?? string.Empty;
                    // Robust PS# detection: trim and check contains to tolerate leading spaces or different formatting
                    bool familyOk = famName.Contains("OpeningOnWall");
                    bool symbolOk = symName.Trim().IndexOf("PS#", System.StringComparison.OrdinalIgnoreCase) >= 0 || symName.IndexOf("PS#", System.StringComparison.OrdinalIgnoreCase) >= 0;
                    return familyOk && symbolOk;
                })
                .ToList();

            // Filter by active 3D section box to reduce candidates
            List<FamilyInstance> sleeves;
            try
            {
                var rawElements = rawSleeves.Cast<Element>().Select(e => (element: (Element)e, transform: (Transform?)null)).ToList();
                var filtered = SectionBoxHelper.FilterElementsBySectionBox(uiDoc, rawElements);
                sleeves = filtered.Select(t => t.element).OfType<FamilyInstance>().ToList();
                DebugLogger.Log($"[PipeOpeningsRect] Raw sleeves={rawSleeves.Count}, Filtered by section box={sleeves.Count}");
                AppendCommandLog($"Raw sleeves={rawSleeves.Count}, Filtered by section box={sleeves.Count}");
                // Diagnostic: list a sample of PS# symbol names to help detect naming variations
                var psNames = rawSleeves.Take(20).Select(fi => fi.Symbol.Name.Replace('\n', ' ')).ToList();
                DebugLogger.Log($"[PipeOpeningsRect] Sample PS# symbol names: {string.Join(", ", psNames)}");
                AppendCommandLog($"Sample PS# symbol names: {string.Join(", ", psNames)}");
                // If section-box filtering yields 0 but raw collection had items, fall back to raw to avoid silent no-op
                if (sleeves.Count == 0 && rawSleeves.Count > 0)
                {
                    var sampleIds = rawSleeves.Take(10).Select(fi => fi.Id.IntegerValue.ToString()).ToList();
                    DebugLogger.Log($"[PipeOpeningsRect] Section-box filtering yielded 0 results; falling back to raw collection of {rawSleeves.Count} sleeves. SampleIds={string.Join(",", sampleIds)}");
                    sleeves = rawSleeves;
                }
            }
            catch (Exception ex)
            {
                DebugLogger.Log($"[PipeOpeningsRect] SectionBox filtering failed: {ex.Message}; falling back to raw collection");
                sleeves = rawSleeves;
            }
            
            if (sleeves.Count == 0)
            {
                return Result.Succeeded;
            }

            // Find rectangular opening symbol
            var allFamilySymbols = new FilteredElementCollector(doc)
                .OfClass(typeof(FamilySymbol))
                .Cast<FamilySymbol>()
                .ToList();

            // Use ClusterOpeningOnWallX family for clusters instead of PipeOpeningOnWallRect
            var rectSymbol = allFamilySymbols
                .FirstOrDefault(sym => sym.Family.Name.Equals("ClusterOpeningOnWallX", System.StringComparison.OrdinalIgnoreCase));
            if (rectSymbol == null)
            {
                TaskDialog.Show("Error", "Please load the ClusterOpeningOnWallX family.");
                return Result.Failed;
            }

            using (var tx = new Transaction(doc, "Place Rectangular Pipe Openings"))
            {
                DebugLogger.Log("Starting transaction: Place Rectangular Pipe Openings");
                tx.Start();
                if (!rectSymbol.IsActive)
                    rectSymbol.Activate();

                // Build map of sleeve to insertion point (use LocationPoint if available)
                var sleeveLocations = sleeves.ToDictionary(
                    s => s,
                    s =>
                    {
                        if (s.Location is LocationPoint lp)
                            return lp.Point;
                        return s.GetTransform().Origin;
                    });

                // Collect all placed pipe sleeves (rectangular and circular) for suppression
                double suppressionTolerance = UnitUtils.ConvertToInternalUnits(100.0, UnitTypeId.Millimeters); // 100mm
                var allPipeSleeves = new FilteredElementCollector(doc)
                    .OfClass(typeof(FamilyInstance))
                    .Cast<FamilyInstance>()
                    .Where(fi => fi.Symbol.Family.Name.Contains("Pipe"))
                    .ToList();
                var allPipeSleeveLocations = allPipeSleeves.ToDictionary(
                    s => s,
                    s => (s.Location as LocationPoint)?.Point ?? s.GetTransform().Origin);

                // Ensure all sleeves have a valid Level and Schedule Level parameter before clustering
                foreach (var sleeve in sleeves)
                {
                    DebugLogger.Log($"Processing sleeve {sleeve.Id.IntegerValue} for level assignment");
                    AppendCommandLog($"Processing sleeve {sleeve.Id.IntegerValue} for level assignment");
                    // Try to get reference level from parameter or helper
                    Level? refLevelNullable = HostLevelHelper.GetHostReferenceLevel(doc, sleeve);
                    Level refLevel;
                    if (refLevelNullable == null)
                    {
                        var pt = (sleeve.Location as LocationPoint)?.Point ?? sleeve.GetTransform().Origin;
                        refLevel = GetNearestPositiveZLevel(doc, pt);
                        DebugLogger.Log($"Using nearest positive Z level for sleeve {sleeve.Id.IntegerValue}: {refLevel?.Name ?? "null"}");
                    }
                    else
                    {
                        refLevel = refLevelNullable;
                        DebugLogger.Log($"Got reference level from helper for sleeve {sleeve.Id.IntegerValue}: {refLevel.Name}");
                    }
                    if (refLevel != null)
                    {
                        Parameter levelParam = sleeve.get_Parameter(BuiltInParameter.FAMILY_LEVEL_PARAM)
                            ?? sleeve.LookupParameter("Level")
                            ?? sleeve.LookupParameter("Reference Level");
                        if (levelParam != null && !levelParam.IsReadOnly && levelParam.StorageType == StorageType.ElementId)
                        {
                            levelParam.Set(refLevel.Id);
                            DebugLogger.Log($"Set Level parameter for sleeve {sleeve.Id.IntegerValue} to {refLevel.Name}");
                        }
                        // Set Schedule Level if available
                        var schedLevelParam = sleeve.LookupParameter("Schedule Level");
                        if (schedLevelParam != null && !schedLevelParam.IsReadOnly)
                        {
                            DebugLogger.Log($"Setting Schedule Level for sleeve {sleeve.Id.IntegerValue}, StorageType: {schedLevelParam.StorageType}");
                            if (schedLevelParam.StorageType == StorageType.ElementId)
                            {
                                schedLevelParam.Set(refLevel.Id);
                                DebugLogger.Log($"Set sleeve {sleeve.Id.IntegerValue} Schedule Level to ElementId: {refLevel.Id.IntegerValue} ({refLevel.Name})");
                            }
                            else if (schedLevelParam.StorageType == StorageType.String)
                            {
                                schedLevelParam.Set(refLevel.Name);
                                DebugLogger.Log($"Set sleeve {sleeve.Id.IntegerValue} Schedule Level to String: '{refLevel.Name}'");
                            }
                            else if (schedLevelParam.StorageType == StorageType.Integer)
                            {
                                schedLevelParam.Set(refLevel.Id.IntegerValue);
                                DebugLogger.Log($"Set sleeve {sleeve.Id.IntegerValue} Schedule Level to Integer: {refLevel.Id.IntegerValue} ({refLevel.Name})");
                            }
                        }
                        else
                        {
                            DebugLogger.Log($"Sleeve {sleeve.Id.IntegerValue} has no Schedule Level parameter or it's read-only");
                        }
                    }
                    else
                    {
                        DebugLogger.Log($"No reference level found for sleeve {sleeve.Id.IntegerValue}");
                    }
                }

                // Group sleeves into clusters where any two within toleranceDistance are connected
                var clusters = new List<List<FamilyInstance>>();
                var unprocessed = new List<FamilyInstance>(sleeves);
                while (unprocessed.Count > 0)
                {
                    var queue = new Queue<FamilyInstance>();
                    var cluster = new List<FamilyInstance>();
                    queue.Enqueue(unprocessed[0]);
                    unprocessed.RemoveAt(0);
                    while (queue.Count > 0)
                    {
                        var inst = queue.Dequeue();
                        cluster.Add(inst);
                        // find neighbors within tolerance (planar XY only)
                        var o1 = sleeveLocations[inst];
                        var neighbors = unprocessed.Where(s =>
                        {
                            XYZ o2 = sleeveLocations[s];
                            // skip if vertical offset exceeds threshold
                            if (Math.Abs(o1.Z - o2.Z) > zTolerance)
                                return false;
                            // compute planar XY gap
                            double dx = o1.X - o2.X;
                            double dy = o1.Y - o2.Y;
                            double planar = Math.Sqrt(dx * dx + dy * dy);
                            // account for sleeve diameters (edge-to-edge gap)
                            double dia1 = inst.LookupParameter("Diameter")?.AsDouble() ?? 0;
                            double dia2 = s.LookupParameter("Diameter")?.AsDouble() ?? 0;
                            double gap = planar - (dia1 / 2.0 + dia2 / 2.0);
                            double gapMm = UnitUtils.ConvertFromInternalUnits(gap, UnitTypeId.Millimeters);
                            DebugLogger.Log($"Edge gap between {inst.Id} and {s.Id}: {gapMm:F1} mm");
                            return gap <= toleranceDist;
                        }).ToList();
                        foreach (var n in neighbors)
                        {
                            queue.Enqueue(n);
                            unprocessed.Remove(n);
                        }
                    }
                    clusters.Add(cluster);
                }
                // Log cluster summary
                DebugLogger.Log($"Cluster formation complete. Total clusters: {clusters.Count}");
                AppendCommandLog($"Cluster formation complete. Total clusters: {clusters.Count}");
                for (int ci = 0; ci < clusters.Count; ci++)
                {
                    DebugLogger.Log($"Cluster {ci}: {clusters[ci].Count} sleeves");
                    AppendCommandLog($"Cluster {ci}: {clusters[ci].Count} sleeves");
                }
                // Process each cluster: one rectangle per cluster of size >=2
                foreach (var cluster in clusters)
                {
                    if (cluster.Count < 2)
                        continue;
                    DebugLogger.Log($"Cluster of {cluster.Count} sleeves detected for replacement.");
                    AppendCommandLog($"Cluster of {cluster.Count} sleeves detected for replacement.");
                    // Use ClusterBoundingBoxServices to get bounding box and midpoint (like RectangularSleeveClusterCommandV2)
                    var (width, height, depth, mid) = ClusterBoundingBoxServices.GetClusterBoundingBox(cluster);
                    // Use reference level from first sleeve in cluster
                    Level? refLevelNullable = HostLevelHelper.GetHostReferenceLevel(doc, cluster[0]);
                    Level refLevel;
                    if (refLevelNullable == null)
                    {
                        var pt = (cluster[0].Location as LocationPoint)?.Point ?? cluster[0].GetTransform().Origin;
                        refLevel = GetNearestPositiveZLevel(doc, pt);
                    }
                    else
                    {
                        refLevel = refLevelNullable;
                    }
                    // OPTIMIZATION: No expensive spatial duplicate detection needed
                    // The cluster formation logic above already prevents duplicates by grouping nearby sleeves
                    // Place the cluster sleeve family instance at the cluster midpoint
                    FamilyInstance inst = doc.Create.NewFamilyInstance(mid, rectSymbol, refLevel, Autodesk.Revit.DB.Structure.StructuralType.NonStructural);
                    // Set Width, Height, Depth parameters mapping model bbox dimensions correctly
                    var widthParam = inst.LookupParameter("Width");
                    var heightParam = inst.LookupParameter("Height");
                    var depthParam = inst.LookupParameter("Depth");
                    // For Depth, use host thickness if available (like RectangularSleeveClusterCommandV2)
                    double hostThickness = width;
                    var wall = cluster[0].Host as Wall;
                    if (wall != null)
                    {
                        hostThickness = wall.get_Parameter(BuiltInParameter.WALL_ATTR_WIDTH_PARAM)?.AsDouble() ?? wall.Width;
                        DebugLogger.Log($"[CLUSTER] Wall thickness used for Depth: {UnitUtils.ConvertFromInternalUnits(hostThickness, UnitTypeId.Millimeters):F1}mm");
                    }
                    if (widthParam != null && !widthParam.IsReadOnly) widthParam.Set(height);   // Y
                    if (heightParam != null && !heightParam.IsReadOnly) heightParam.Set(depth); // Z
                    if (depthParam != null && !depthParam.IsReadOnly) depthParam.Set(hostThickness); // X
                    placedCount++;
                    DebugLogger.Log($"Rectangular opening created with id {inst.Id.IntegerValue} (total placed: {placedCount})");
                    AppendCommandLog($"Rectangular opening created with id {inst.Id.IntegerValue} (total placed: {placedCount}) width={UnitUtils.ConvertFromInternalUnits(width, UnitTypeId.Millimeters):F1}mm height={UnitUtils.ConvertFromInternalUnits(height, UnitTypeId.Millimeters):F1}mm depth={UnitUtils.ConvertFromInternalUnits(depth, UnitTypeId.Millimeters):F1}mm mid={mid}");
                    // Delete originals
                    foreach (var s in cluster)
                    {
                        doc.Delete(s.Id);
                        deletedCount++;
                    }
                    DebugLogger.Log($"Deleted {cluster.Count} circular sleeves (total deleted: {deletedCount})");
                    AppendCommandLog($"Deleted {cluster.Count} circular sleeves (total deleted: {deletedCount})");
                }
                tx.Commit();
            }

            // Simple summary dialog - no intrusive details
            // Info dialog removed as requested
            return Result.Succeeded;
        }

        // Helper to get the nearest positive Z level (at or above the given Z)
        public static Level GetNearestPositiveZLevel(Document doc, XYZ point)
        {
            var levels = new FilteredElementCollector(doc).OfClass(typeof(Level)).Cast<Level>().ToList();
            // Only consider levels at or above the point's Z
            var aboveOrAt = levels.Where(l => l.Elevation >= point.Z).OrderBy(l => l.Elevation - point.Z).ToList();
            if (aboveOrAt.Any())
                return aboveOrAt.First();
            // Fallback: nearest level (if all are below)
            return levels.OrderBy(l => Math.Abs(l.Elevation - point.Z)).FirstOrDefault();
        }

        // Helper to get the nearest level strictly below the given Z
        public static Level GetNearestLevelBelowZ(Document doc, XYZ point)
        {
            var levels = new FilteredElementCollector(doc).OfClass(typeof(Level)).Cast<Level>().ToList();
            // Only consider levels strictly below the point's Z
            var below = levels.Where(l => l.Elevation < point.Z).OrderByDescending(l => l.Elevation).ToList();
            if (below.Any())
                return below.First();
            // Fallback: lowest level in the project
            return levels.OrderBy(l => l.Elevation).FirstOrDefault();
        }
    }
    }
